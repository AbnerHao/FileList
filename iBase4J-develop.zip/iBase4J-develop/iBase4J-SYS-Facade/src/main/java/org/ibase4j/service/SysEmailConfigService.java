package org.ibase4j.service;

import org.ibase4j.model.SysEmailConfig;

import top.ibase4j.core.base.BaseService;

/**
 * @author ShenHuaJie
 *
 */
public interface SysEmailConfigService extends BaseService<SysEmailConfig> {

}
