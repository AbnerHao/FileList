package org.ibase4j.service;

import org.ibase4j.model.SysNotice;

import top.ibase4j.core.base.BaseService;

/**
 * @author ShenHuaJie
 *
 */
public interface SysNoticeService extends BaseService<SysNotice> {

}
