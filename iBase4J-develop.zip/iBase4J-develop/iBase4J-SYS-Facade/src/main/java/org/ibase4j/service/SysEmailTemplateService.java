package org.ibase4j.service;

import org.ibase4j.model.SysEmailTemplate;

import top.ibase4j.core.base.BaseService;

/**
 * @author ShenHuaJie
 *
 */
public interface SysEmailTemplateService extends BaseService<SysEmailTemplate> {

}
