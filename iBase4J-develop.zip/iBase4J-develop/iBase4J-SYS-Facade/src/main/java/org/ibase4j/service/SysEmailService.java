package org.ibase4j.service;

import org.ibase4j.model.SysEmail;

import top.ibase4j.core.base.BaseService;

/**
 * @author ShenHuaJie
 *
 */
public interface SysEmailService extends BaseService<SysEmail> {

}
