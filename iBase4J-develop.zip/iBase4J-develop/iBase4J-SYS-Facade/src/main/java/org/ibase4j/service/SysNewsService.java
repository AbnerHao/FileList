package org.ibase4j.service;

import org.ibase4j.model.SysNews;

import top.ibase4j.core.base.BaseService;

/**
 * @author ShenHuaJie
 *
 */
public interface SysNewsService extends BaseService<SysNews> {

}
